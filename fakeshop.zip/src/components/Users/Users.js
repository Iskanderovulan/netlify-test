import React from 'react';

const Users = () => {
    return (
        <div>
            <h2>Users</h2>
        </div>
    );
};

export default Users;