const API = 'https://fakestoreapi.com/'

export const API_PRODUCTS = API + 'products/'
export const API_CATEGORY = `${API_PRODUCTS}category/`
export const API_CATEGORIES = `${API_PRODUCTS}categories`


export const API_USERS = API + 'users'

// 'https://fakestoreapi.com/products/categories'